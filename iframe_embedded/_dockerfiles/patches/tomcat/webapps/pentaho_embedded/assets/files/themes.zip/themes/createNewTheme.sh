#!/bin/bash

# Builds a project that is in the project subdirectory. It always uses
# a local pentaho server image to build from, so that has to exist previously

# 1. Define new folder Name
# 2  Define Main Color and second Color
# 3. Clean it

BASEDIR=$(dirname $0)
cd $BASEDIR
PROJECTS_DIR="projects"


# 1. Define new folder Name
read -e -p "> Define folder Name: " PROJECTNA
PROJECTNA=${PROJECTNA:-"-1"}
if [ $PROJECTNA == "-1" ] #check if variable is empty
then
	echo "Please define a project Name"
	exit 1;
fi
	mkdir $PROJECTNA
	#1.1 Check if folder exist
	if [ $? -eq 0 ]
	then
	  echo
	  echo "Created folder: "$PROJECTNA
	  echo
	else
	  exit $?
	fi


tmpDir=tmp/buildFolderThemeTmp
# 2 Define Main Color and second Color
	read -e -p "> Define Main Color [#cc0000]:" COLOR1
	COLOR1=${COLOR1:-"#cc0000"}
	read -e -p "> Define Second Color [#7C0B2B]:" COLOR2
	COLOR2=${COLOR2:-"#7C0B2B"}
	
	echo
	echo "Folder name: "$PROJECTNA
	echo  "Main Color: " $COLOR1
	echo  "Second Color: " $COLOR2
	echo
	echo  "To change logo image update logo.svg in folder $PROJECTNA\logo-image (size recomended 250*65)"
	echo  "And after run the command ./changeLogo.sh in folder $PROJECTNA\logo-image " 
	echo
	
	mkdir -p $tmpDir
	cp -r newFolderTheme/* $tmpDir
	
	sed -i.bak "s/\${MAINCOLOR}/$COLOR1/g;s/\${SECONDCOLOR}/$COLOR2/g" $tmpDir/pentaho-solutions/system/analyzer/styles/themes/myTheme/anamyTheme.css && \
	sed -i.bak "s/\${MAINCOLOR}/$COLOR1/g;s/\${SECONDCOLOR}/$COLOR2/g" $tmpDir/pentaho-solutions/system/common-ui/resources/themes/myTheme/globalmyTheme.css && \
	sed -i.bak "s/\${MAINCOLOR}/$COLOR1/g;s/\${SECONDCOLOR}/$COLOR2/g" $tmpDir/tomcat/webapps/pentaho/mantle/themes/myTheme/mantlemyTheme.css
	
	cp -r $tmpDir/* $PROJECTNA

# 3. Clean it

rm -rf $tmpDir

echo 
echo Folder built successfully
echo

cd $BASEDIR

exit 0
