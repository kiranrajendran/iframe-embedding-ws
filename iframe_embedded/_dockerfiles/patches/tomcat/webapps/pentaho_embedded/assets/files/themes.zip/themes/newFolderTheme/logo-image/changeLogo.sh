#!/bin/bash

# Builds a project that is in the project subdirectory. It always uses
# a local pentaho server image to build from, so that has to exist previously

# 1. Update logo

BASEDIR=$(dirname $0)
cd $BASEDIR
PROJECTS_DIR="projects"




#1. Update logo
cp -r logo.svg ../pentaho-solutions/system/common-ui/resources/themes/myTheme/images/logo.svg


echo 
echo Logo copy successfully
echo

exit 0
