# Change Logo image


You can change the User Console login page to display a different logo than the default one, such as your corporate logo or other image.

Copy your image to this folder (size recomended 250*65)

Rename your own logo image to logo.svg.

