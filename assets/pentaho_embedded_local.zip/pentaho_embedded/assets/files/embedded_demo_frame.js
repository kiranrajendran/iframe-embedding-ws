'<!-- http://localhost:8081/pentaho/api/repos//public/Steel Wheels/Sales Performance (dashboard).xdash/viewer?userid=Admin&password=password -->'
'<iframe id="demoFrame" border="0" frameborder="0" src="blank_page.html" style="width: 100%; height: 800px">'
        'Your browser does not support inline frames or is currently configured not to display inline frames.'
'</iframe>'