define([
  "css!./model.css",
  "css!../crystal/tipsy.css"
], function() {
});
